package me.strawberryyu.heroplant

import taboolib.common.platform.Plugin
import taboolib.common.platform.function.info

object HeroPlant : Plugin() {

    override fun onEnable() {
        info("Successfully running ExamplePlugin!")
    }
}